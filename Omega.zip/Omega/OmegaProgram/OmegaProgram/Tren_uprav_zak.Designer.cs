﻿namespace OmegaProgram
{
	partial class Tren_zak_info_ui
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.zpet_button = new System.Windows.Forms.Button();
			this.seznam_infor_lbl = new System.Windows.Forms.Label();
			this.upravit_vse = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label1.Location = new System.Drawing.Point(15, 134);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(161, 29);
			this.label1.TabIndex = 2;
			this.label1.Text = "Skupina žáků:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label2.Location = new System.Drawing.Point(371, 134);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(58, 29);
			this.label2.TabIndex = 3;
			this.label2.Text = "Žák:";
			// 
			// zpet_button
			// 
			this.zpet_button.Location = new System.Drawing.Point(49, 686);
			this.zpet_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.zpet_button.Name = "zpet_button";
			this.zpet_button.Size = new System.Drawing.Size(75, 27);
			this.zpet_button.TabIndex = 4;
			this.zpet_button.Text = "Zpět";
			this.zpet_button.UseVisualStyleBackColor = true;
			this.zpet_button.Click += new System.EventHandler(this.zpet_button_Click);
			// 
			// seznam_infor_lbl
			// 
			this.seznam_infor_lbl.AutoSize = true;
			this.seznam_infor_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.seznam_infor_lbl.Location = new System.Drawing.Point(44, 253);
			this.seznam_infor_lbl.Name = "seznam_infor_lbl";
			this.seznam_infor_lbl.Size = new System.Drawing.Size(18, 25);
			this.seznam_infor_lbl.TabIndex = 6;
			this.seznam_infor_lbl.Text = " ";
			// 
			// upravit_vse
			// 
			this.upravit_vse.BackColor = System.Drawing.Color.SpringGreen;
			this.upravit_vse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.upravit_vse.ForeColor = System.Drawing.Color.Black;
			this.upravit_vse.Location = new System.Drawing.Point(579, 555);
			this.upravit_vse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.upravit_vse.Name = "upravit_vse";
			this.upravit_vse.Size = new System.Drawing.Size(75, 28);
			this.upravit_vse.TabIndex = 8;
			this.upravit_vse.Text = "Uložit";
			this.upravit_vse.UseVisualStyleBackColor = false;
			this.upravit_vse.Click += new System.EventHandler(this.upravit_vse_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(191, 136);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(160, 24);
			this.comboBox1.TabIndex = 10;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
			// 
			// comboBox2
			// 
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(439, 134);
			this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(160, 24);
			this.comboBox2.TabIndex = 11;
			this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label3.Location = new System.Drawing.Point(252, 41);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(282, 37);
			this.label3.TabIndex = 12;
			this.label3.Text = "Informace o žákovi";
			// 
			// Tren_zak_info_ui
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Navy;
			this.ClientSize = new System.Drawing.Size(800, 793);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.comboBox2);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.upravit_vse);
			this.Controls.Add(this.seznam_infor_lbl);
			this.Controls.Add(this.zpet_button);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.ForeColor = System.Drawing.Color.White;
			this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.Name = "Tren_zak_info_ui";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Informace o žákovi";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Tren_zak_info_ui_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button zpet_button;
		private System.Windows.Forms.Label seznam_infor_lbl;
		private System.Windows.Forms.Button upravit_vse;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.Label label3;
	}
}