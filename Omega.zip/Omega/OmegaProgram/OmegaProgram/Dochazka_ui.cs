﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Skupiny_metody;
using static OmegaProgram.Treninky_metody;
using static OmegaProgram.Dochazka_metody;
namespace OmegaProgram
{
	public partial class Dochazka_ui : Form
	{
		List<ComboBox> combolist = new List<ComboBox>();
		List<Label> labels = new List<Label>();
		List<Label> labelsD = new List<Label>();
		List<string> Zaci = new List<string>();
		List<string> prezence = new List<string>();


		public Dochazka_ui()
		{
			InitializeComponent();
			vytvoritD_button.Hide();
			upravitD_button.Hide();
			List<string> Skupiny = Get_skupiny_of_trener();
			foreach (string Skupina in Skupiny)
			{
				comboBox4.Items.Add(Skupina);
			}
		}


		private void zpet_Click(object sender, EventArgs e)
		{
			this.Hide();
			Trener_ui a1 = new Trener_ui();
			a1.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			if (comboBox4.SelectedItem == null)
			{
				MessageBox.Show("Vyberte prosím pro jakou skupinu");
			}
			else
			{
				comboBox1.Items.Clear();
				vytvoritD_button.Show();
				List<string> data = Get_treninky_futurePast_week(comboBox4.Text);
				foreach (string d in data)
				{
					comboBox1.Items.Add(d);
				}
				List<string> Zaci = Get_athletes_thru_skupina(comboBox4.Text);

				panel1.Show();
				int a = 286;
				for (int i = 0; i < Zaci.Count; i++)
				{
					ComboBox combos = new ComboBox();
					combos.Location = new Point(191, a);
					combos.Size = new System.Drawing.Size(100, 25);
					combos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
					combos.ForeColor = System.Drawing.Color.White;
					combos.Items.Add("Přítomen");
					combos.Items.Add("Nepřítomen");
					combos.Items.Add("Omluven");
					combolist.Add(combos);
					a += 30;
				}

				foreach (ComboBox c in combolist)
				{
					this.Controls.Add(c);
				}
				panel_zaku.Show();
			}


		}

		private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
		{
			foreach (Label l in labelsD)
			{
				this.Controls.Remove(l);
			}
			labelsD.Clear();
			foreach (ComboBox c in combolist)
			{
				this.Controls.Remove(c);
			}
			combolist.Clear();

			if (comboBox1.Text != null)
			{

				comboBox1.Items.Clear();
				List<string> data = Get_treninky_futurePast_week(comboBox4.Text);
				foreach (string d in data)
				{
					comboBox1.Items.Add(d);
				}


				foreach (Label l in labels)
				{
					this.Controls.Remove(l);
				}
				labels.Clear();

				Zaci = Get_athletes_thru_skupina(comboBox4.Text);
				int a = 286;
				for (int i = 0; i < Zaci.Count; i++)
				{
					Label mylab = new Label();
					mylab.Text = Zaci[i];
					mylab.Location = new Point(30, a);
					mylab.AutoSize = true;
					mylab.Font = new Font("Calibri", 12);
					mylab.ForeColor = Color.White;
					mylab.Padding = new Padding(6);
					labels.Add(mylab);
					a += 30;
				}
				foreach (Label l in labels)
				{
					this.Controls.Add(l);
				}
				panel_zaku.Show();
			}
			else
			{
				MessageBox.Show("Nejdříve musíte vybrat skupinu!");
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedItem == null || comboBox4.SelectedItem == null)
			{
				MessageBox.Show("Musíte vybrat skupinu a datum!");
			}
			else
			{

				for (int i = 0; i < labels.Count; i++)
				{
					if (combolist[i].SelectedItem == null)
					{
						MessageBox.Show("U jednoho žáka nebyla vybrána prezence");
					}
					else
					{
						Insert_to_dochazka(labels[i].Text, comboBox1.Text, combolist[i].Text);
					}
				}
				MessageBox.Show("Docházka se uložila do databáze");
				comboBox1_SelectedIndexChanged(sender, e);
			}
		}




		private void button6_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < labels.Count; i++)
			{
				if (combolist[i].SelectedItem == null)
				{
					MessageBox.Show("U jednoho žáka nebyla vybrána");
				}
				else
				{
					Update_dochazka(labels[i].Text, comboBox1.Text, combolist[i].Text);
				}
			}
			MessageBox.Show("Docházka se uložila do databáze");
			//Vypis dochazky
			comboBox1_SelectedIndexChanged(sender, e);
		}


		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (comboBox4.SelectedItem == null)
			{
				MessageBox.Show("Nejdříve vyberte skupinu");
			}
			else
			{
				List<string> Zaci = Get_athletes_thru_skupina(comboBox4.Text);
				prezence.Clear();
				prezence.Add(Select_dochazka(Zaci[0], comboBox1.Text));

				if (prezence[0] == null)//hlídá jestli už není docházka k tréninku hotová
				{
					upravitD_button.Hide();
					vytvoritD_button.Show();//pokud docházka neexistuje
				}
				else
				{
					upravitD_button.Show();
					vytvoritD_button.Hide();
					foreach (Label l in labelsD)
					{
						this.Controls.Remove(l);
					}
					labelsD.Clear();
					prezence.Clear();
					foreach (string zak in Zaci)
					{
						prezence.Add(Select_dochazka(zak, comboBox1.Text));
					}
					int a = 286;
					for (int i = 0; i < prezence.Count; i++)
					{
						Label mylab = new Label();
						mylab.Text = prezence[i];
						mylab.Location = new Point(191, a);
						mylab.AutoSize = true;
						mylab.Font = new Font("Calibri", 12);
						mylab.ForeColor = Color.White;
						mylab.Padding = new Padding(6);
						labelsD.Add(mylab);
						a += 30;
					}
					foreach (Label l in labelsD)
					{
						this.Controls.Add(l);
					}

				}
				int b = 294;
				for (int i = 0; i < Zaci.Count; i++)
				{
					ComboBox combos = new ComboBox();
					combos.Location = new Point(320, b);
					combos.Size = new System.Drawing.Size(100, 25);
					combos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
					combos.ForeColor = System.Drawing.Color.White;
					combos.Items.Add("Přítomen");
					combos.Items.Add("Nepřítomen");
					combos.Items.Add("Omluven");
					combolist.Add(combos);
					b += 30;
				}

				foreach (ComboBox c in combolist)
				{
					this.Controls.Add(c);
				}
			}
		}

		private void Dochazka_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}


