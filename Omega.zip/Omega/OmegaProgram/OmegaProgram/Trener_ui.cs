﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static OmegaProgram.Treneri_metody;

namespace OmegaProgram
{
	public partial class Trener_ui : Form
	{
		public Trener_ui()
		{
			InitializeComponent();
			List<string> udaje = Get_name_surname_of_trener();
			jmeno_lbl.Text = udaje[0];
			prijmeni_lbl.Text = udaje[1];
		}
	

		private void zak_info_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Tren_zak_info_ui a1 = new Tren_zak_info_ui();
			a1.Show();
		}

		private void zpet_button_Click_1(object sender, EventArgs e)
		{
			this.Hide();
			Prihlaseni_ui a1 = new Prihlaseni_ui();
			a1.ShowDialog();
		}
		private void dochazka_Click(object sender, EventArgs e)
		{
			this.Hide();
			Dochazka_ui a1 = new Dochazka_ui();
			a1.Show();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Treninky_akce_ui a1 = new Treninky_akce_ui();
			a1.Show();
		}

	
	}
}
