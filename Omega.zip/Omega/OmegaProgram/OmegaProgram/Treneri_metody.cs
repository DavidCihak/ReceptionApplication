﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Uzivatele_metody;
using static OmegaProgram.Zaci_metody;

namespace OmegaProgram
{
	class Treneri_metody
	{
		
		/// <summary>
		/// Method for creating new log into table treneri
		/// </summary>
		/// <param name="id_uziv"></param>
		/// <param name="jmeno"></param>
		/// <param name="prijmeni"></param>
		/// <param name="pohlavi"></param>
		/// <param name="tel_cis"></param>
		public static void Insert_trenera(string id_uziv, string jmeno, string prijmeni, string pohlavi, string tel_cis)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "insert into treneri(id_uziv, jmeno, prijmeni, pohlavi, tel_cis) values(@id_uziv,@jmeno,@prijmeni,@pohlavi,@tel_cis);";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@id_uziv", SqlDbType.Int);
			command.Parameters["@id_uziv"].Value = id_uziv;
			command.Parameters.Add("@jmeno", SqlDbType.NVarChar);
			command.Parameters["@jmeno"].Value = jmeno;
			command.Parameters.Add("@prijmeni", SqlDbType.NVarChar);
			command.Parameters["@prijmeni"].Value = prijmeni;
			command.Parameters.Add("@pohlavi", SqlDbType.NVarChar);
			command.Parameters["@pohlavi"].Value = pohlavi;
			command.Parameters.Add("@tel_cis", SqlDbType.Int);
			command.Parameters["@tel_cis"].Value = tel_cis;
			command.ExecuteNonQuery();
			cnn.Close();
		}

		/// <summary>
		/// Method for getting id of trener through id of uzivatele
		/// </summary>
		/// <param name="id_user"></param>
		/// <returns>string id of trener</returns>
		public static string Get_id_of_trener_thru_user_id(string id_user)
		{
			SqlConnection cnn = ConnectDB();
			string id_tren = null;
			string prikaz_id_tren = "Select id_trener from treneri where id_uziv = " + id_user + ";";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_tren = reader["id_trener"].ToString();
				}
			}
			return id_tren;
		}
		/// <summary>
		/// Method for getting id of trener through id of logged uzivatele
		/// </summary>
		/// <returns>string id of trener</returns>
		public static string Get_id_of_trener()
		{
			SqlConnection cnn = ConnectDB();
			string id_tren = null;
			string prikaz_id_tren = "Select id_trener from treneri where id_uziv = " + Get_id_of_user() + ";";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_tren = reader["id_trener"].ToString();
				}
			}
			return id_tren;
		}
		public static string Get_id_of_trener_thru_name(string jmeno_prijemni)
		{
			SqlConnection cnn = ConnectDB();
			string[] text = Split_date_others(jmeno_prijemni);
			string id_tren = null;
			string prikaz_id_tren = "Select id_trener from treneri where jmeno = '" + text[0] + "' and prijmeni = '"+text[1]+"';";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_tren = reader["id_trener"].ToString();
				}
			}
			return id_tren;
		}
		/// <summary>
		/// Method for getting name and surname of concrete trener through id_uzivatele
		/// </summary>
		/// <returns>list of strings with name and surname</returns>
		public static List<string> Get_name_surname_of_trener()
		{
			SqlConnection cnn = ConnectDB();
			List<string> udaje = new List<string>();
			string prikaz_udaje = "Select jmeno, prijmeni from treneri where id_uziv = " + Get_id_of_user() + ";";
			SqlCommand command2 = new SqlCommand(prikaz_udaje, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					udaje.Add(reader["jmeno"].ToString());
					udaje.Add(reader["prijmeni"].ToString());
				}
			}
			cnn.Close();
			return udaje;

		}
	}
}
