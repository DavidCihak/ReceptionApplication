﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using static OmegaProgram.Zaci_metody;

namespace OmegaProgram
{
	class Pripojeni_db
	{
		static string login_db;
		static string password_db;

		/// <summary>
		/// Method read form config file and make new connection to DB server threw connection string
		/// </summary>
		/// <returns>sql connection</returns>
		public static SqlConnection ConnectDB()
		{
			string[] lines;
			try
			{
				string fileName = "DB_Udaje.txt";
				string path = Path.Combine(Environment.CurrentDirectory, @"Data\");
				string pathB = Path.Combine(path, fileName);
				lines = System.IO.File.ReadAllLines(pathB);
			} 
			catch(FileNotFoundException e)
			{
				throw e;
			}
			List<string> udaje = new List<string>();
			for(int i = 0; i < 4; i++)
			{
				string[] udaj = Split_date_others(lines[i]);
				udaje.Add(udaj[1]);
			}
			
			SqlConnection cnn;
			string connetionString;
			connetionString = @"Data Source=" + udaje[0] + ";Initial Catalog=" + udaje[1] + ";User ID=" + udaje[2] + ";Password=" + udaje[3] + "";
			cnn = new SqlConnection(connetionString);
			try
			{
				cnn.Open();
			} catch(Exception e)
			{
				Application.Exit();
			}

			return cnn;
		}
		/// <summary>
		/// Method checkig if login and password are correct(exist in DB)
		/// </summary>
		/// <param name="log"></param>
		/// <param name="hes"></param>
		/// <returns>if they have match return TRUE</returns>
		public static bool Sing_on(string log, string hes)
		{
			SqlConnection cnn = ConnectDB();
			Dictionary<string, string> login_heslo_db = new Dictionary<string, string>();
			string prikaz = "select username, heslo, typ_uziv from uzivatele where username = @log and heslo = @hes;";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@log", SqlDbType.NVarChar);
			command.Parameters.Add("@hes", SqlDbType.NVarChar);
			command.Parameters["@log"].Value = log;
			command.Parameters["@hes"].Value = hes;

			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					login_db = reader["username"].ToString();
					password_db = reader["heslo"].ToString();
					login_heslo_db.Add(login_db, password_db);
				}
			}

			if (login_heslo_db.Count < 1)
			{
				MessageBox.Show("Spatny login nebo heslo");
				return false;
			}
			else
			{
				return true;
			}
		}
		/// <summary>
		/// Method for getting login
		/// </summary>
		/// <returns>string of accepted login</returns>
		public static string get_login()
		{
			return login_db;
		}
		/// <summary>
		/// Method for getting password
		/// </summary>
		/// <returns>string of accepted password</returns>
		public static string get_heslo()
		{
			return password_db;
		}



	}
}
