﻿using System;

namespace OmegaProgram
{
	partial class Prihlaseni_ui
	{
		/// <summary>
		/// Vyžaduje se proměnná návrháře.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Uvolněte všechny používané prostředky.
		/// </summary>
		/// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Kód generovaný Návrhářem Windows Form

		/// <summary>
		/// Metoda vyžadovaná pro podporu Návrháře - neupravovat
		/// obsah této metody v editoru kódu.
		/// </summary>
		private void InitializeComponent()
		{
			this.prihlasit_button = new System.Windows.Forms.Button();
			this.login_lbl = new System.Windows.Forms.Label();
			this.heslo_lbl = new System.Windows.Forms.Label();
			this.heslo_box = new System.Windows.Forms.TextBox();
			this.login_box = new System.Windows.Forms.TextBox();
			this.headline = new System.Windows.Forms.Label();
			this.registrace = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// prihlasit_button
			// 
			this.prihlasit_button.BackColor = System.Drawing.Color.CornflowerBlue;
			this.prihlasit_button.Cursor = System.Windows.Forms.Cursors.Hand;
			this.prihlasit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.prihlasit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.prihlasit_button.Location = new System.Drawing.Point(103, 155);
			this.prihlasit_button.Name = "prihlasit_button";
			this.prihlasit_button.Size = new System.Drawing.Size(100, 31);
			this.prihlasit_button.TabIndex = 0;
			this.prihlasit_button.Text = "Přihlásit se";
			this.prihlasit_button.UseVisualStyleBackColor = false;
			this.prihlasit_button.Click += new System.EventHandler(this.button1_Click);
			// 
			// login_lbl
			// 
			this.login_lbl.AutoSize = true;
			this.login_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.login_lbl.Location = new System.Drawing.Point(43, 77);
			this.login_lbl.Name = "login_lbl";
			this.login_lbl.Size = new System.Drawing.Size(53, 17);
			this.login_lbl.TabIndex = 1;
			this.login_lbl.Text = "Login:";
			// 
			// heslo_lbl
			// 
			this.heslo_lbl.AutoSize = true;
			this.heslo_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.heslo_lbl.Location = new System.Drawing.Point(43, 114);
			this.heslo_lbl.Name = "heslo_lbl";
			this.heslo_lbl.Size = new System.Drawing.Size(54, 17);
			this.heslo_lbl.TabIndex = 2;
			this.heslo_lbl.Text = "Heslo:";
			// 
			// heslo_box
			// 
			this.heslo_box.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.heslo_box.Location = new System.Drawing.Point(103, 111);
			this.heslo_box.Name = "heslo_box";
			this.heslo_box.PasswordChar = '●';
			this.heslo_box.Size = new System.Drawing.Size(100, 23);
			this.heslo_box.TabIndex = 3;
			// 
			// login_box
			// 
			this.login_box.Location = new System.Drawing.Point(103, 77);
			this.login_box.Name = "login_box";
			this.login_box.Size = new System.Drawing.Size(100, 22);
			this.login_box.TabIndex = 4;
			// 
			// headline
			// 
			this.headline.AutoSize = true;
			this.headline.Font = new System.Drawing.Font("Palatino Linotype", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.headline.Location = new System.Drawing.Point(86, 9);
			this.headline.Name = "headline";
			this.headline.Size = new System.Drawing.Size(138, 37);
			this.headline.TabIndex = 6;
			this.headline.Text = "Přihlášení";
			// 
			// registrace
			// 
			this.registrace.BackColor = System.Drawing.Color.Transparent;
			this.registrace.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
			this.registrace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.registrace.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.registrace.ForeColor = System.Drawing.Color.SpringGreen;
			this.registrace.Location = new System.Drawing.Point(103, 207);
			this.registrace.Name = "registrace";
			this.registrace.Size = new System.Drawing.Size(100, 30);
			this.registrace.TabIndex = 7;
			this.registrace.Text = "Registrace";
			this.registrace.UseVisualStyleBackColor = false;
			this.registrace.Click += new System.EventHandler(this.registrace_Click);
			// 
			// Prihlaseni_ui
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Gray;
			this.ClientSize = new System.Drawing.Size(315, 261);
			this.Controls.Add(this.registrace);
			this.Controls.Add(this.headline);
			this.Controls.Add(this.login_box);
			this.Controls.Add(this.heslo_box);
			this.Controls.Add(this.heslo_lbl);
			this.Controls.Add(this.login_lbl);
			this.Controls.Add(this.prihlasit_button);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Prihlaseni_ui";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Přihlášení";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Prihlaseni_ui_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button prihlasit_button;
		private System.Windows.Forms.Label login_lbl;
		private System.Windows.Forms.Label heslo_lbl;
		private System.Windows.Forms.TextBox heslo_box;
		private System.Windows.Forms.TextBox login_box;
		private System.Windows.Forms.Label headline;
		private System.Windows.Forms.Button registrace;
	}
	
}

