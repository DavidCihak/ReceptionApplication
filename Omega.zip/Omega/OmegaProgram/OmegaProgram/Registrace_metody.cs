﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Pripojeni_db;


namespace OmegaProgram
{
	class Registrace_metody
	{
		/// <summary>
		/// Method for creating new registration of user and adding new log to table uzivatele
		/// </summary>
		/// <param name="username"></param>
		/// <param name="password"></param>
		/// <param name="typ"></param>
		public static void Insert_user(string username, string password, string typ_uziv)
		{
			SqlConnection cnn = ConnectDB();

			string prikaz = "insert into uzivatele(username, heslo, typ_uziv) values (@username,@password,@typ_uziv);";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@username", SqlDbType.NVarChar);
			command.Parameters["@username"].Value = username;
			command.Parameters.Add("@password", SqlDbType.NVarChar);
			command.Parameters["@password"].Value = password;
			command.Parameters.Add("@typ_uziv", SqlDbType.NVarChar);
			command.Parameters["@typ_uziv"].Value = typ_uziv;
			command.ExecuteNonQuery();
			cnn.Close();

		}
		/// <summary>
		/// Method for creating now log in table zaci
		/// </summary>
		/// <param name="id_uziv"></param>
		/// <param name="jmeno"></param>
		/// <param name="prijmeni"></param>
		/// <param name="dat_naroz"></param>
		/// <param name="pohlavi"></param>
		public static void Insert_zaka(string id_uziv, string jmeno, string prijmeni, string dat_naroz, string pohlavi)
		{
			string[] text = Split_date_others(dat_naroz);
			string datum = text[2] + "-" + text[1] + "-" + text[0];
			SqlConnection cnn = ConnectDB();
			string prikaz = "insert into zaci(id_uziv,id_skup,jmeno,prijmeni,dat_naroz,vyska_cm,hmotnost_kg,pohlavi,bmi,poznamka_zraneni_strava) values(@id_uziv , null, @jmeno, @prijmeni, @datum, 0.0, 0, @pohlavi, 0, 'nic');";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@id_uziv", SqlDbType.Int);
			command.Parameters["@id_uziv"].Value = id_uziv;
			command.Parameters.Add("@jmeno", SqlDbType.NVarChar);
			command.Parameters["@jmeno"].Value = jmeno;
			command.Parameters.Add("@prijmeni", SqlDbType.NVarChar);
			command.Parameters["@prijmeni"].Value = prijmeni;
			command.Parameters.Add("@datum", SqlDbType.Date);
			command.Parameters["@datum"].Value = datum;
			command.Parameters.Add("@pohlavi", SqlDbType.NVarChar);
			command.Parameters["@pohlavi"].Value = pohlavi;
			command.ExecuteNonQuery();
			cnn.Close();
		}
		public static bool Check_username(string username)
		{
			SqlConnection cnn = ConnectDB();
			string id_uziv = null;
			string id_uziv_comm = "select id_uziv from uzivatele where username = '" + username + "';";
			SqlCommand command1 = new SqlCommand(id_uziv_comm, cnn);
			using (SqlDataReader reader = command1.ExecuteReader())
			{
				while (reader.Read())
				{
					id_uziv = reader["id_uziv"].ToString();
				}
			}
			if (id_uziv == null)
			{
				return false;
			}
			else
			{
				return true;
			}

		}

	}
}
