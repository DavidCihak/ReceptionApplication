﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static OmegaProgram.Admin_metody;


namespace OmegaProgram
{
	public partial class Admin_ui : Form
	{

		public Admin_ui()
		{
			InitializeComponent();
			panel1.Hide();
			panel3.Hide();
			button3.Hide();
			button4.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			button3.Show();
			comboBox1.Items.Clear();
			List<string> All_athlets = Get_all_athlets();
			foreach (string athlet in All_athlets)
			{
				comboBox1.Items.Add(athlet);
			}
			comboBox3.Items.Clear();
			List<string> All_groups = Get_all_groups();
			foreach (string group in All_groups)
			{
				comboBox3.Items.Add(group);
			}
			panel1.Show();
			panel3.Hide();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			List<string> All_users = Get_all_users();
			foreach (string user in All_users)
			{
				comboBox5.Items.Add(user);
			}
			panel3.Show();
			panel1.Hide();
			
		}

		private void button2_Click(object sender, EventArgs e)
		{
			button4.Show();
			panel1.Show();
			panel3.Hide();
			comboBox1.Items.Clear();
			List<string> All_treners = Get_all_trainers();
			foreach (string trener in All_treners)
			{
				comboBox1.Items.Add(trener);
			}
			List<string> All_groups = Get_all_groups();
			foreach (string group in All_groups)
			{
				comboBox3.Items.Add(group);
			}

		}

		private void button6_Click(object sender, EventArgs e)
		{
			
			if (comboBox5.SelectedItem == null)
			{
				MessageBox.Show("Vyberte údaje!");
			}
			else
			{
				DialogResult r = MessageBox.Show("Opravdu si přejete odstranit uživatele?", "Potvrzení", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
				if (r == DialogResult.Yes)
				{
					Delete_user(comboBox5.Text);
					panel1.Hide();
					panel3.Hide();
					MessageBox.Show("Uživatel " + comboBox5.Text + " byl odstrněn z DB!");
				}
			}
			comboBox5.Items.Clear();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedItem == null || comboBox3.SelectedItem == null)
			{
				MessageBox.Show("Vyberte údaje!");
			}
			else
			{
				Update_athlets_groups(comboBox1.Text, comboBox3.Text);
				panel1.Hide();
				panel3.Hide();
				MessageBox.Show("Skupina byla přidána!");
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			this.Hide();
			Prihlaseni_ui a1 = new Prihlaseni_ui();
			a1.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedItem == null || comboBox3.SelectedItem == null)
			{
				MessageBox.Show("Vyberte údaje!");
			}
			else
			{
				Update_trainer_groups(comboBox1.Text, comboBox3.Text);
				MessageBox.Show("Skupina byla přidána!");
				panel3.Hide();
				panel1.Hide();
			}
			

		}

		private void Admin_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}
