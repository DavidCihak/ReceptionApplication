use Omega;

insert into uzivatele (username, heslo, typ_uziv)values
('david', 'david', 'trener'),
('honza', 'honza', 'zak'),
('rais', '#krestan', 'trener'),
('marek', 'marecek123', 'zak'),
('matous', 'matous', 'zak'),
('vitkovaneka', 'nela', 'zak'),
('admin', 'admin', 'admin'),
('kacka', 'kacka', 'zak');

insert into treneri(id_uziv, jmeno, prijmeni, pohlavi, tel_cis) values
(1, 'David', '�ih�k', 'male', 727727727),
(3, 'Benjamin', 'Rais', 'male', 666666666);

insert into skupiny(id_skup,id_trener, nazev) values
(1, 1, 'P��pravka'),
(2, 1, 'Mlad�� ��ci'),
(3, 2, 'Dorost'),
(4, 1, 'Idividual Vitkova');

insert into zaci(id_uziv,id_skup,jmeno,prijmeni,dat_naroz,vyska_cm,hmotnost_kg,pohlavi,bmi,poznamka_zraneni_strava) values
(2,1,'Jan', '�ern�', '2012-01-01', 130.5, 30, 'male', 0, 'nic'),
(4,2,'Marek', 'Lauryn', '2008-02-02', 165.5, 50, 'male', 0, 'nic'),
(5,3,'Matou�', 'Chvojka', '2005-03-03', 180.0, 69, 'male', 0, 'nic'),
(6,4,'Nela', 'V�tkov�', '2002-08-22', 165.0, 50, 'female', 0, 'Vla�sk� o�echy, kiwi, gran�tov� jablka'),
(7,1,'Kate�ina', 'Proch�zkov�', '2003-09-09', 171.5, 45, 'female', 0, 'Pyl');


insert into treninky(id_skup, nazev, popis, datum_cas,delka_min) values
(1, 'Nohy', 'S vlastn� vahou', '2021-12-12 16:30:00', 90),
(1, 'Ruce', 'S vlastn� vahou', '2021-12-19 16:30:00', 90),
(1, 'Hrudn�k', 'S vlastn� vahou', '2021-12-26 16:30:00', 90),
(1, 'Cardio', 'S vlastn� vahou', '2022-02-01 16:30:00', 90),

(4, 'Joga', 'D�ch�n�', '2021-12-12 18:30:00', 60),
(4, 'Joga', 'Prota�en�', '2021-12-19 18:30:00', 60),
(4, 'Joga', 'D�raz - technika', '2021-12-26 18:30:00', 60),
(4, 'Joga', 'Pos�len� - core', '2022-02-01 18:30:00', 60),

(2, 'Nohy', 'S vlastn� vahou', '2021-12-12 15:30:00', 60),
(2, 'Ruce', 'S vlastn� vahou', '2021-12-19 15:30:00', 60),
(2, 'Hrudn�k', 'S vlastn� vahou', '2021-12-26 16:30:00', 60),
(2, 'Cardio', 'S vlastn� vahou', '2022-02-01 15:30:00', 60),

(3, 'Nohy', 'V posilovn�', '2021-12-12 16:30:00', 45),
(3, 'Ruce', 'V posilovn�', '2021-12-19 16:30:00', 45),
(3, 'Hrudn�k', 'V posilovn�', '2021-12-26 16:30:00', 45),
(3, 'Cardio', 'V posilovn�', '2022-02-01 16:30:00', 45),

(1, 'Nohy', 'V posilovn�', '2022-04-25 16:30:00', 45),
(1, 'Ruce', 'V posilovn�', '2022-04-24 16:30:00', 45),
(1, 'Hrudn�k', 'V posilovn�', '2022-04-17 16:30:00', 45),
(1, 'Cardio', 'V posilovn�', '2022-04-18 16:30:00', 45);


