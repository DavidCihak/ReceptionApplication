﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static OmegaProgram.Uzivatele_metody;
using static OmegaProgram.Registrace_metody;
using static OmegaProgram.Treneri_metody;
using System.Text.RegularExpressions;

namespace OmegaProgram
{
	public partial class Registrace : Form
	{
		public Registrace()
		{
			InitializeComponent();
			pictureBox1.Hide();
			pictureBox2.Hide();
			pictureBox3.Hide();
			button2.Hide();

		}

		List<CheckBox> checkBoxes = new List<CheckBox>();
		List<TextBox> TBlist = new List<TextBox>();
		TextBox txt = new TextBox();
		DateTimePicker dateTimePicker1 = new DateTimePicker();

		bool trener;
		bool heslo = false;
		bool nick = false;

		string id_user;
		string usernameString;
		string passwordString;
		string uzivatelString;


		private void button1_Click(object sender, EventArgs e)
		{

			if (checkBox1.Checked == true && checkBox2.Checked == true)
			{
				MessageBox.Show("Vyberte pouze jeden typ uživatele!");
			}
			else if (checkBox1.Checked == false && checkBox2.Checked == false)
			{
				MessageBox.Show("Musíte vybrat jeden typ uživatele!");

			}
			else if (Check_username(textBox1.Text))
			{
				MessageBox.Show("Toto uživatelské jméno již existuje.");
			}
			else if (textBox2.Text != textBox3.Text)
			{
				MessageBox.Show("Hesla se neshodují.");
			}
			else
			{

				button1.Hide();
				panel2.Hide();
				button2.Show();
				List<string> hlavickyZaci = new List<string>();
				hlavickyZaci.Clear();
				hlavickyZaci.Add("Jméno: ");
				hlavickyZaci.Add("Příjmení: ");

				if (checkBox1.Checked == true)
				{
					usernameString = textBox1.Text;
					passwordString = textBox2.Text;
					uzivatelString = "zak";
					trener = false;

					hlavickyZaci.Add("Datum narození: ");

					dateTimePicker1.Font = new Font("Calibri", 10.2F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(238)));
					dateTimePicker1.Format = DateTimePickerFormat.Short;
					dateTimePicker1.Location = new Point(430, 90);
					dateTimePicker1.Size = new Size(129, 28);
					dateTimePicker1.TabIndex = 14;
					this.Controls.Add(dateTimePicker1);
				}
				else if (checkBox2.Checked == true)
				{
					usernameString = textBox1.Text;
					passwordString = textBox2.Text;
					uzivatelString = "trener";
					trener = true;
					hlavickyZaci.Add("Telefonní číslo: ");

					txt.Location = new Point(430, 90);
					txt.AutoSize = false;
					txt.Size = new System.Drawing.Size(100, 20);
					txt.Font = new Font("Calibri", 12);
					txt.ForeColor = Color.Black;
					txt.BackColor = Color.White;
					txt.Padding = new Padding(6);
					this.Controls.Add(txt);
				}

				List<Label> labels = new List<Label>();
				int a = 40;
				for (int i = 0; i < hlavickyZaci.Count; i++)
				{
					Label mylab = new Label();
					mylab.Text = hlavickyZaci[i];
					mylab.Location = new Point(280, a);
					mylab.AutoSize = true;
					mylab.Font = new Font("Calibri", 12);
					mylab.ForeColor = Color.Black;
					mylab.Padding = new Padding(6);
					labels.Add(mylab);
					this.Controls.Add(mylab);
					a += 25;
				}


				int ya = 40;

				for (int i = 0; i < 2; i++)
				{
					TextBox txt = new TextBox();
					txt.Location = new Point(430, ya);
					txt.AutoSize = false;
					txt.Size = new System.Drawing.Size(100, 20);
					txt.Font = new Font("Calibri", 12);
					txt.ForeColor = Color.Black;
					txt.BackColor = Color.White;
					txt.Padding = new Padding(6);
					TBlist.Add(txt);
					this.Controls.Add(txt);
					ya += 25;
				}
				TBlist.Add(txt);


				int x = 300;
				for (int i = 0; i < 2; i++)
				{
					CheckBox checkBox3 = new System.Windows.Forms.CheckBox();
					checkBox3.AutoSize = true;
					checkBox3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
					checkBox3.Location = new System.Drawing.Point(x, 200);
					checkBox3.Size = new System.Drawing.Size(72, 28);
					checkBox3.TabIndex = 4;
					if (i == 0)
					{
						checkBox3.Text = "Muž";
					}
					else
					{
						checkBox3.Text = "Žena";
					}
					checkBox3.UseVisualStyleBackColor = true;
					checkBoxes.Add(checkBox3);
					this.Controls.Add(checkBox3);
					x += 130;
				}
			}
		}
		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			if (textBox1.Text.Length == 0 || textBox1.Text == " ")
			{
				pictureBox1.Hide();
				nick = false;
			}
			else
			{
				bool exists = Check_username(textBox1.Text);
				if (exists == false)
				{
					pictureBox1.Show();
					nick = true;
				}
				else
				{
					pictureBox1.Hide();
				}
			}
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			if (textBox1.Text.Length == 0 || textBox1.Text == " ")
			{
				pictureBox1.Hide();
			}
			else
			{
				if (pictureBox1.Visible == true)
				{
					pictureBox2.Show();
				}
			}

		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{
			if (textBox1.Text.Length == 0 || textBox1.Text == " ")
			{
				pictureBox1.Hide();
				heslo = false;
			}
			else
			{
				if (textBox2.Text == textBox3.Text)
				{
					pictureBox3.Show();
					heslo = true;
				}
				else
				{
					pictureBox3.Hide();
				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Regex regex = new Regex(@"^\d{9}$");
			MatchCollection matches = regex.Matches(TBlist[2].Text);

			if (checkBoxes[0].Checked == true && checkBoxes[1].Checked == true)
			{
				MessageBox.Show("Vyberte pouze jeden typ pohlaví!");
			}
			else if (checkBoxes[0].Checked == false && checkBoxes[1].Checked == false)
			{
				MessageBox.Show("Musíte vybrat jedno pohlaví");
			}
			else if (heslo == false)
			{
				MessageBox.Show("Hesla nejsou shodná");
			}
			else if (nick == false)
			{
				MessageBox.Show("Toto uživatelské jméno již někdo používá");
			}
			if(checkBox2.Checked == true)
			{
				if (matches.Count < 1)
				{
					MessageBox.Show("Telefonní číslo musí obsahovat 9 číslic a žádné jiné znaky.");
				}
			}
			else
			{

				Insert_user(usernameString, passwordString, uzivatelString);
				id_user = Get_id_of_user_nick(usernameString);
				if (checkBoxes[0].Checked == true)
				{
					//muž

					if (trener == true)
					{
						Insert_trenera(id_user, TBlist[0].Text, TBlist[1].Text, "male", TBlist[2].Text);
					}
					else
					{
						Insert_zaka(id_user, TBlist[0].Text, TBlist[1].Text, dateTimePicker1.Text, "male");
					}
				}
				if (checkBoxes[1].Checked == true)
				{
					//žena
					if (trener == true)
					{
						Insert_trenera(id_user, TBlist[0].Text, TBlist[1].Text, "female", TBlist[2].Text);
					}
					else
					{
						Insert_zaka(id_user, TBlist[0].Text, TBlist[1].Text, dateTimePicker1.Text, "female");
					}


				}
				button2.Hide();
				MessageBox.Show("Registrace proběhla úspěšně.");
				this.Hide();
				Prihlaseni_ui a1 = new Prihlaseni_ui();
				a1.ShowDialog();
			}


		}

		private void zpet_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Prihlaseni_ui a1 = new Prihlaseni_ui();
			a1.ShowDialog();
		}

		private void Registrace_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}


