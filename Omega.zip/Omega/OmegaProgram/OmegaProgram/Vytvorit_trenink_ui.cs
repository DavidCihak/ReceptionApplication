﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static OmegaProgram.Treninky_metody;
using static OmegaProgram.Skupiny_metody;
using System.Text.RegularExpressions;

namespace OmegaProgram
{
	public partial class Vytvorit_trenink_ui : Form
	{
		public Vytvorit_trenink_ui()
		{
			InitializeComponent();
			List<string> Skupiny = Get_skupiny_of_trener();
			foreach (string skupina in Skupiny)
			{
				comboBox1.Items.Add(skupina);
			}
			
		}

		private void pridat_Click(object sender, EventArgs e)
		{
			Regex regex = new Regex(@"^\d{2,5}$");
			MatchCollection matches = regex.Matches(textBox4.Text);
			if (textBox5.Text.Length == 0 || textBox2.Text.Length == 0 || textBox4.Text.Length == 0 || matches.Count < 1||comboBox1.SelectedItem == null)
			{
				MessageBox.Show("Některý z údajů je špatně vyplněný");
			}
			else
			{
				string id_skup = Get_id_skup(comboBox1.Text);
				dateTimePicker1.Format = DateTimePickerFormat.Custom;
				dateTimePicker1.CustomFormat = "yyyy-MM-dd";
				string datum_cas = dateTimePicker1.Text + " " + dateTimePicker2.Text;
				Insert_trenink(id_skup, textBox5.Text, textBox2.Text, datum_cas, textBox4.Text);
				MessageBox.Show("Trénink byl přidán.");
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Treninky_akce_ui a1 = new Treninky_akce_ui();
			a1.ShowDialog();
		}

		private void Vytvorit_trenink_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}
