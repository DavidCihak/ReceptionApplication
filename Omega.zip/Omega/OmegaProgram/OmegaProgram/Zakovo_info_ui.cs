﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Uzivatele_metody;
namespace OmegaProgram
{
	public partial class Zakovo_info_ui : Form
	{
		public Zakovo_info_ui()
		{
			InitializeComponent();
			List<string> udaje = Get_name_surname_of_zak();
			jmeno_lbl.Text = udaje[0];
			prijmeni_lbl.Text = udaje[1];
			label1.Text = Get_something_from_zaci("vyska_cm")+ " cm";
			label2.Text = Get_something_from_zaci("hmotnost_kg")+ " kg";
			label3.Text = Get_something_from_zaci("bmi");
			label4.Text = Get_bazal_of_zak().ToString();
		
		}

		private void zpet_button_Click(object sender, EventArgs e)
		{

			this.Hide();
			Zak_ui a1 = new Zak_ui();
			a1.ShowDialog();
		}

		private void Zakovo_info_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();

		}
	}
}
