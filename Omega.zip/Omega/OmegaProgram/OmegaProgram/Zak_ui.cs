﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Uzivatele_metody;
namespace OmegaProgram
{
	public partial class Zak_ui : Form
	{
		public Zak_ui()
		{
			InitializeComponent();
			List<string> udaje = Get_name_surname_of_zak();
			jmeno_lbl.Text = udaje[0];
			prijmeni_lbl.Text = udaje[1];
		}

		private void inf_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Zakovo_info_ui a1 = new Zakovo_info_ui();
			a1.ShowDialog();
		}

		private void dochazka_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Zak_treninky a1 = new Zak_treninky();
			a1.ShowDialog();
		}

		private void zpet_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Prihlaseni_ui a1 = new Prihlaseni_ui();
			a1.ShowDialog();
		}

	}
}
