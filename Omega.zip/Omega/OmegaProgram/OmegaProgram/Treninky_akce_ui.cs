﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static OmegaProgram.Skupiny_metody;
using static OmegaProgram.Treninky_metody;

namespace OmegaProgram
{
	public partial class Treninky_akce_ui : Form
	{
		public Treninky_akce_ui()
		{
			InitializeComponent();
			label1.Hide();
			button1.Hide();
			button3.Hide();
			panel3.Show();
			panel1.Hide();
			List<string> Skupiny = Get_skupiny_of_trener();
			foreach (string skupina in Skupiny)
			{
				comboBox1.Items.Add(skupina);
			}
		}
			private void zpet_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Trener_ui a1 = new Trener_ui();
			a1.ShowDialog();
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			List<string> data = Get_treninky_futurePast_week(comboBox1.Text);
			comboBox2.Items.Clear();
			foreach (string d in data)
			{
				comboBox2.Items.Add(d);
			}
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			label1.Text = "";
			string id_skup = Get_id_skup(comboBox1.Text);
			string id_tren = Get_id_of_trenink(comboBox2.Text);
			List<string> treninky = Select_treninky_thru_idSku_idTrenink(id_skup, id_tren);
			foreach (string trenink in treninky)
			{
				label1.Text = "\n" + label1.Text + trenink + ",";
			}
			label1.Show();
			button1.Show();
			button3.Show();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string id_skup = Get_id_skup(comboBox1.Text);
			string id_tren = Get_id_of_trenink(comboBox2.Text);
			Delete_trenink(id_skup, id_tren);
			MessageBox.Show("Trénink byl odstraněn!");
			comboBox2.Items.Clear();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			string id_skup = Get_id_skup(comboBox1.Text);
			string id_tren = Get_id_of_trenink(comboBox2.Text);
			Update_trenink_choose(id_skup, id_tren, comboBox3.Text, textBox7.Text);
			MessageBox.Show("Změna se uložila do Databáze");
			comboBox2_SelectedIndexChanged(sender, e);
		}

		private void button3_Click(object sender, EventArgs e)
		{
			panel1.Show();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			this.Hide();
			Vytvorit_trenink_ui a1 = new Vytvorit_trenink_ui();
			a1.ShowDialog();
		}

	}
}
