use Omega;
create table uzivatele(
id_uziv int IDENTITY(1,1) primary key not null,
username nvarchar(30) unique not null,
heslo nvarchar(30) not null,
typ_uziv nvarchar(30) not null check (typ_uziv in('zak','trener','admin'))
);

create table treneri(
id_trener int IDENTITY(1,1) primary key not null,
id_uziv int foreign key (id_uziv) references uzivatele(id_uziv) on delete cascade,
jmeno nvarchar(30) not null,
prijmeni nvarchar(30) not null,
pohlavi VARCHAR(10) NOT NULL CHECK (pohlavi IN('male', 'female')), --ENUM parametr
tel_cis int not null
);	

create table skupiny(
id_skup int primary key not null,
id_trener int foreign key (id_trener) references treneri(id_trener) on delete cascade,
nazev nvarchar(30) not null,
);

create table zaci(
id_zak int IDENTITY(1,1) primary key not null,
id_uziv int foreign key (id_uziv) references uzivatele(id_uziv),
id_skup int foreign key (id_skup) references skupiny(id_skup) on delete cascade,
jmeno nvarchar(30) not null,
prijmeni nvarchar(30) not null,
dat_naroz date not null,
vyska_cm float,
hmotnost_kg float,
pohlavi varchar(10) NOT NULL CHECK (pohlavi IN('male', 'female')), --ENUM parametr
bmi float,
poznamka_zraneni_strava nvarchar(100)
);

create table treninky(
id_trenink int IDENTITY(1,1) PRIMARY KEY not null,
id_skup int foreign key (id_skup) references skupiny(id_skup) on delete cascade,
nazev nvarchar(30) not null,
popis nvarchar(100),
datum_cas datetime not null,
delka_min int not null
);
 
create table dochazka(
id_dochaz int IDENTITY(1,1) primary key not null,
id_zak int foreign key (id_zak) references zaci(id_zak) on delete cascade,
id_trenink int foreign key (id_trenink) references treninky(id_trenink),
prezence varchar(10) NOT NULL CHECK (prezence IN('P��tomen', 'Nep��tomen', 'Omluven')), --ENUM parametr
);

