﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Skupiny_metody;
using System.Drawing;

namespace OmegaProgram
{
	public partial class Tren_zak_info_ui : Form
	{
		

		public Tren_zak_info_ui()
		{
			InitializeComponent();
			upravit_vse.Hide();


			List<string> Skupiny = Get_skupiny_of_trener();
			foreach (string skupina in Skupiny)
			{
				comboBox1.Items.Add(skupina);
			}
		}


		private void zpet_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Trener_ui a1 = new Trener_ui();
			a1.ShowDialog();
		}

		List<string> hlavicky = new List<string>();
		List<Label> labels = new List<Label>();
		List<TextBox> TBlist = new List<TextBox>();
		RichTextBox info = new RichTextBox();


		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			upravit_vse.Show();
			int yc = 253;
			hlavicky.Clear();
			hlavicky.Add("Jméno:");
			hlavicky.Add("Přijmení:");
			hlavicky.Add("Datum narození:");
			hlavicky.Add("Výška (cm):");
			hlavicky.Add("Hmotnost (Kg):");
			hlavicky.Add("BMI:");
			hlavicky.Add("Informace:");
			foreach (Label l in labels)
			{
				this.Controls.Remove(l);
			}
			for (int i = 0; i < hlavicky.Count; i++)
			{
				Label txt = new Label();
				txt.Location = new Point(70, yc);
				txt.Text = hlavicky[i];
				txt.AutoSize = true;
				txt.Font = new Font("Calibri", 12);
				txt.ForeColor = Color.White;
				labels.Add(txt);
				yc += 30;
			}
			foreach (Label l in labels)
			{
				this.Controls.Add(l);
			}

			List<string> seznam_infor_lbl = Select_all_from_zaci(comboBox2.Text);
			foreach (TextBox t in TBlist)
			{
				this.Controls.Remove(t);
			}
			int ya = 253;
			TBlist.Clear();
			for (int i = 0; i < 6; i++)
			{
				TextBox txt = new TextBox();
				txt.Location = new Point(220, ya);
				txt.Text = seznam_infor_lbl[i];
				txt.AutoSize = false;
				txt.Size = new System.Drawing.Size(180, 20);
				txt.Font = new Font("Calibri", 12);
				txt.ForeColor = Color.Black;
				txt.BackColor = Color.White;
				txt.Padding = new Padding(6);
				TBlist.Add(txt);
				ya += 30;
			}
			foreach (TextBox t in TBlist)
			{
				this.Controls.Add(t);
			}

			this.Controls.Remove(info);
			info.Location = new Point(220, ya);
			info.Text = seznam_infor_lbl[6];
			info.AutoSize = false;
			info.Size = new System.Drawing.Size(180, 80);
			info.Font = new Font("Calibri", 12);
			info.ForeColor = Color.Black;
			info.Padding = new Padding(6);
			this.Controls.Add(info);
		}

		private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
		{
			comboBox2.Items.Clear();
			List<string> Zaci = Get_athletes_thru_skupina(comboBox1.Text);
			foreach (string zak in Zaci)
			{
				comboBox2.Items.Add(zak);
			}
		}
		List<string> vse = new List<string>();
		private void upravit_vse_Click(object sender, EventArgs e)
		{
			vse.Clear();
			string id_zak = Get_id_of_athelet_thru_name(comboBox2.Text);	
			foreach (TextBox t in TBlist)
			{
				if(t.Text.Length == 0)
				{
					vse.Add(" ");
				}
				else
				{
					vse.Add(t.Text);
				}
				
			}
			if(info.Text.Length == 0)
			{
				vse.Add(" ");
			}
			else
			{
				vse.Add(info.Text);
			}
			Update_athlete_all(vse, id_zak);
			MessageBox.Show("Úprava se uložila do Databáze");
			comboBox2_SelectedIndexChanged(sender, e);
		}

		private void Tren_zak_info_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}
