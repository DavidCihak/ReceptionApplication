﻿namespace OmegaProgram
{
	partial class Vytvorit_trenink_ui
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pridat = new System.Windows.Forms.Button();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.delka = new System.Windows.Forms.Label();
			this.datum = new System.Windows.Forms.Label();
			this.popis = new System.Windows.Forms.Label();
			this.naz_skup = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.dateTimePicker2);
			this.panel1.Controls.Add(this.comboBox1);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.dateTimePicker1);
			this.panel1.Controls.Add(this.textBox5);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.pridat);
			this.panel1.Controls.Add(this.textBox4);
			this.panel1.Controls.Add(this.textBox2);
			this.panel1.Controls.Add(this.delka);
			this.panel1.Controls.Add(this.datum);
			this.panel1.Controls.Add(this.popis);
			this.panel1.Controls.Add(this.naz_skup);
			this.panel1.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.panel1.Location = new System.Drawing.Point(64, 82);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(427, 265);
			this.panel1.TabIndex = 5;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.dateTimePicker2.CustomFormat = "hh:mm";
			this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker2.Location = new System.Drawing.Point(147, 154);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(73, 23);
			this.dateTimePicker2.TabIndex = 5;
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(147, 39);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(186, 23);
			this.comboBox1.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(144, 134);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(57, 17);
			this.label2.TabIndex = 14;
			this.label2.Text = "Začátek:";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(147, 99);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(186, 23);
			this.dateTimePicker1.TabIndex = 4;
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(147, 11);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(186, 23);
			this.textBox5.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label1.Location = new System.Drawing.Point(3, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(97, 17);
			this.label1.TabIndex = 10;
			this.label1.Text = "Název tréninku:\r\n";
			// 
			// pridat
			// 
			this.pridat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.pridat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.pridat.Location = new System.Drawing.Point(147, 195);
			this.pridat.Name = "pridat";
			this.pridat.Size = new System.Drawing.Size(186, 41);
			this.pridat.TabIndex = 7;
			this.pridat.Text = "Vytvořit";
			this.pridat.UseVisualStyleBackColor = false;
			this.pridat.Click += new System.EventHandler(this.pridat_Click);
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(260, 154);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(73, 23);
			this.textBox4.TabIndex = 6;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(147, 69);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(186, 23);
			this.textBox2.TabIndex = 3;
			// 
			// delka
			// 
			this.delka.AutoSize = true;
			this.delka.Location = new System.Drawing.Point(257, 134);
			this.delka.Name = "delka";
			this.delka.Size = new System.Drawing.Size(76, 17);
			this.delka.TabIndex = 4;
			this.delka.Text = "Délka (min):";
			// 
			// datum
			// 
			this.datum.AutoSize = true;
			this.datum.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.datum.Location = new System.Drawing.Point(3, 103);
			this.datum.Name = "datum";
			this.datum.Size = new System.Drawing.Size(94, 17);
			this.datum.TabIndex = 3;
			this.datum.Text = "Datum tréniku:";
			// 
			// popis
			// 
			this.popis.AutoSize = true;
			this.popis.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.popis.Location = new System.Drawing.Point(3, 72);
			this.popis.Name = "popis";
			this.popis.Size = new System.Drawing.Size(91, 17);
			this.popis.TabIndex = 2;
			this.popis.Text = "Popis tréninku:";
			// 
			// naz_skup
			// 
			this.naz_skup.AutoSize = true;
			this.naz_skup.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.naz_skup.Location = new System.Drawing.Point(3, 42);
			this.naz_skup.Name = "naz_skup";
			this.naz_skup.Size = new System.Drawing.Size(91, 17);
			this.naz_skup.TabIndex = 0;
			this.naz_skup.Text = "Název skupiny:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(23, 404);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 34);
			this.button1.TabIndex = 6;
			this.button1.Text = "Zpět";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Calibri", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label3.Location = new System.Drawing.Point(156, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(295, 53);
			this.label3.TabIndex = 7;
			this.label3.Text = "Vytvořit trénink";
			// 
			// Vytvorit_trenink_ui
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Navy;
			this.ClientSize = new System.Drawing.Size(678, 444);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.panel1);
			this.ForeColor = System.Drawing.Color.White;
			this.Name = "Vytvorit_trenink_ui";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Vytvorit_trenink_uics";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Vytvorit_trenink_ui_FormClosing);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button pridat;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label delka;
		private System.Windows.Forms.Label datum;
		private System.Windows.Forms.Label popis;
		private System.Windows.Forms.Label naz_skup;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
	}
}