﻿namespace OmegaProgram
{
	partial class Zakovo_info_ui
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.bazal_lbl = new System.Windows.Forms.Label();
			this.bmi_lbl = new System.Windows.Forms.Label();
			this.vaha_lbl = new System.Windows.Forms.Label();
			this.vyska_lbl = new System.Windows.Forms.Label();
			this.prijmeni_lbl = new System.Windows.Forms.Label();
			this.jmeno_lbl = new System.Windows.Forms.Label();
			this.uzivatel_lbl = new System.Windows.Forms.Label();
			this.zpet_button = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// bazal_lbl
			// 
			this.bazal_lbl.AutoSize = true;
			this.bazal_lbl.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.bazal_lbl.Location = new System.Drawing.Point(49, 233);
			this.bazal_lbl.Name = "bazal_lbl";
			this.bazal_lbl.Size = new System.Drawing.Size(211, 21);
			this.bazal_lbl.TabIndex = 18;
			this.bazal_lbl.Text = "Bazální metabolismus (Kcal):";
			// 
			// bmi_lbl
			// 
			this.bmi_lbl.AutoSize = true;
			this.bmi_lbl.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.bmi_lbl.Location = new System.Drawing.Point(49, 202);
			this.bmi_lbl.Name = "bmi_lbl";
			this.bmi_lbl.Size = new System.Drawing.Size(45, 21);
			this.bmi_lbl.TabIndex = 17;
			this.bmi_lbl.Text = "BMI:";
			// 
			// vaha_lbl
			// 
			this.vaha_lbl.AutoSize = true;
			this.vaha_lbl.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.vaha_lbl.Location = new System.Drawing.Point(49, 173);
			this.vaha_lbl.Name = "vaha_lbl";
			this.vaha_lbl.Size = new System.Drawing.Size(49, 21);
			this.vaha_lbl.TabIndex = 16;
			this.vaha_lbl.Text = "Váha:";
			// 
			// vyska_lbl
			// 
			this.vyska_lbl.AutoSize = true;
			this.vyska_lbl.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.vyska_lbl.Location = new System.Drawing.Point(49, 142);
			this.vyska_lbl.Name = "vyska_lbl";
			this.vyska_lbl.Size = new System.Drawing.Size(56, 21);
			this.vyska_lbl.TabIndex = 15;
			this.vyska_lbl.Text = "Výška:";
			// 
			// prijmeni_lbl
			// 
			this.prijmeni_lbl.AutoSize = true;
			this.prijmeni_lbl.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.prijmeni_lbl.Location = new System.Drawing.Point(469, 112);
			this.prijmeni_lbl.Name = "prijmeni_lbl";
			this.prijmeni_lbl.Size = new System.Drawing.Size(79, 24);
			this.prijmeni_lbl.TabIndex = 14;
			this.prijmeni_lbl.Text = "Přijmení";
			// 
			// jmeno_lbl
			// 
			this.jmeno_lbl.AutoSize = true;
			this.jmeno_lbl.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.jmeno_lbl.Location = new System.Drawing.Point(386, 112);
			this.jmeno_lbl.Name = "jmeno_lbl";
			this.jmeno_lbl.Size = new System.Drawing.Size(64, 24);
			this.jmeno_lbl.TabIndex = 13;
			this.jmeno_lbl.Text = "Jméno";
			// 
			// uzivatel_lbl
			// 
			this.uzivatel_lbl.AutoSize = true;
			this.uzivatel_lbl.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.uzivatel_lbl.Location = new System.Drawing.Point(49, 112);
			this.uzivatel_lbl.Name = "uzivatel_lbl";
			this.uzivatel_lbl.Size = new System.Drawing.Size(46, 24);
			this.uzivatel_lbl.TabIndex = 12;
			this.uzivatel_lbl.Text = "Žák:";
			// 
			// zpet_button
			// 
			this.zpet_button.Location = new System.Drawing.Point(12, 413);
			this.zpet_button.Name = "zpet_button";
			this.zpet_button.Size = new System.Drawing.Size(75, 28);
			this.zpet_button.TabIndex = 20;
			this.zpet_button.Text = "Zpět";
			this.zpet_button.UseVisualStyleBackColor = true;
			this.zpet_button.Click += new System.EventHandler(this.zpet_button_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(3, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(0, 17);
			this.label1.TabIndex = 21;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Font = new System.Drawing.Font("Calibri", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.panel1.Location = new System.Drawing.Point(384, 142);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(200, 119);
			this.panel1.TabIndex = 22;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(3, 94);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(42, 17);
			this.label4.TabIndex = 25;
			this.label4.Text = "label4";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(3, 63);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 17);
			this.label3.TabIndex = 24;
			this.label3.Text = "label3";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(3, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(42, 17);
			this.label2.TabIndex = 23;
			this.label2.Text = "label2";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Calibri", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label5.Location = new System.Drawing.Point(215, 9);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(201, 53);
			this.label5.TabIndex = 23;
			this.label5.Text = "Informace";
			// 
			// Zakovo_info_ui
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.ClientSize = new System.Drawing.Size(682, 453);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.zpet_button);
			this.Controls.Add(this.bazal_lbl);
			this.Controls.Add(this.bmi_lbl);
			this.Controls.Add(this.vaha_lbl);
			this.Controls.Add(this.vyska_lbl);
			this.Controls.Add(this.prijmeni_lbl);
			this.Controls.Add(this.jmeno_lbl);
			this.Controls.Add(this.uzivatel_lbl);
			this.ForeColor = System.Drawing.Color.White;
			this.Name = "Zakovo_info_ui";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Informace";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Zakovo_info_ui_FormClosing);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label bazal_lbl;
		private System.Windows.Forms.Label bmi_lbl;
		private System.Windows.Forms.Label vaha_lbl;
		private System.Windows.Forms.Label vyska_lbl;
		private System.Windows.Forms.Label prijmeni_lbl;
		private System.Windows.Forms.Label jmeno_lbl;
		private System.Windows.Forms.Label uzivatel_lbl;
		private System.Windows.Forms.Button zpet_button;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
	}
}