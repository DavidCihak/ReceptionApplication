﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static OmegaProgram.Treninky_metody;
using static OmegaProgram.Skupiny_metody;

namespace OmegaProgram
{
	public partial class Zak_treninky : Form
	{
		public Zak_treninky()
		{
			//FormBorderStyle = FormBorderStyle.None;
			//WindowState = FormWindowState.Maximized;
			TopMost = true;
			InitializeComponent();
			panel1.Hide();
			label3.Hide();
			List<string> skupiny = Get_skupiny_of_zak();
			foreach (string skup in skupiny) 
			{ 
			comboBox1.Items.Add(skup);
			}
		}
		private void zpet_button_Click(object sender, EventArgs e)
		{
			this.Hide();
			Zak_ui a1 = new Zak_ui();
			a1.ShowDialog();
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			List<string> Treninky = Get_trainings_of_athlete(comboBox1.Text);
			panel1.Show();
			label3.Show();
			for(int i = Treninky.Count()-1; i > 0; i--)
			{
				label1.Text = label1.Text+ "\n" + Treninky[i] + "\n";
			}

			}

		private void Zak_treninky_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
	}

