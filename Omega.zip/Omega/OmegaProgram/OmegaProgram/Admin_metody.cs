﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Data;
using System.Text;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Skupiny_metody;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Treneri_metody;
using static OmegaProgram.Uzivatele_metody;


namespace OmegaProgram
{/// <summary>
 /// Iclude methods that only user logged as admin can do
 /// </summary>
	class Admin_metody
	{

		/// <summary>
		/// Method for deleting user + log in table zaci/treneri from table uzivatele
		/// </summary>
		/// <param name="username"></param>
		public static void Delete_user(string username)
		{
			SqlConnection cnn = ConnectDB();
			string id_user = Get_id_of_user_nick(username);
			string id_zak = Get_id_of_athlete_thru_user_id(id_user);
			string id_trener = Get_id_of_trener_thru_user_id(id_user);
			string type_of_user = Get_type_of_user_thru_user_id(id_user);
			string prikaz = "delete from uzivatele where username = @username;";
			string prikazZ = "delete from zaci where id_zak = @id_zak;";
			string prikazT = "delete from treneri where id_trener = @id_tren;";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			SqlCommand commandT = new SqlCommand(prikazT, cnn);
			SqlCommand commandZ = new SqlCommand(prikazZ, cnn);
			command.Parameters.Add("@username", SqlDbType.NVarChar);
			commandZ.Parameters.Add("@id_zak", SqlDbType.Int);
			commandT.Parameters.Add("@id_tren", SqlDbType.Int);
			command.Parameters["@username"].Value = username;
			commandZ.Parameters["@id_zak"].Value = id_zak;
			commandT.Parameters["@id_tren"].Value = id_trener;
			if (type_of_user == "zak")
			{
				commandZ.ExecuteNonQuery();

			}
			else if (type_of_user == "trener")
			{
				commandT.ExecuteNonQuery();
			}
			command.ExecuteNonQuery();
			

			cnn.Close();
		}

		/// <summary>
		/// Method for updating group of concrete athelte
		/// </summary>
		/// <param name="name_of_athlete"></param>
		/// <param name="name_of_group"></param>
		public static void Update_athlets_groups(string name_of_athlete, string name_of_group)
		{
			string[] text = Split_date_others(name_of_athlete);
			SqlConnection cnn = ConnectDB();
			string prikaz = "Update zaci set id_skup = " + Get_id_skup(name_of_group) + "where jmeno = '" + text[0] + "' and prijmeni = '" + text[1] + "';";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();

		}
		/// <summary>
		/// Method to add new trainer to concrete group od athlets
		/// </summary>
		/// <param name="name_of_trener"></param>
		/// <param name="name_of_group"></param>
		public static void Update_trainer_groups(string name_of_trener, string name_of_group)
		{
			string[] text = Split_date_others(name_of_trener);
			SqlConnection cnn = ConnectDB();
			string id_trener = Get_id_of_trener_thru_name(name_of_trener);
			string prikaz = "Update skupiny set id_trener = " + id_trener + " where id_skup = "+Get_id_skup(name_of_group)+";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();

		}
		/// <summary>
		/// Method for getting names of all athlets from table Zaci
		/// </summary>
		/// <returns>List of strings of names and surnames</returns>
		public static List<string> Get_all_athlets()
		{
			SqlConnection cnn = ConnectDB();
			List<string> All_athlets = new List<string>();
			string prikaz = "Select * from zaci;";
			SqlCommand command2 = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					All_athlets.Add(reader["jmeno"].ToString() + " " + reader["prijmeni"].ToString());
				}
			}
			cnn.Close();
			return All_athlets;

		}
		/// <summary>
		/// Method for getting names of all trainers from table Treneri
		/// </summary>
		/// <returns>List of strings of names and surnames</returns>
		public static List<string> Get_all_trainers()
		{
			SqlConnection cnn = ConnectDB();
			List<string> All_trainers = new List<string>();
			string prikaz = "Select * from treneri;";
			SqlCommand command2 = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					All_trainers.Add(reader["jmeno"].ToString() + " " + reader["prijmeni"].ToString());
				}
			}
			cnn.Close();
			return All_trainers;

		}
		/// <summary>
		/// Method for getting nicknames of all users from table uzivatele
		/// </summary>
		/// <returns>List of strings of nicknames</returns>
		public static List<string> Get_all_users()
		{
			SqlConnection cnn = ConnectDB();
			List<string> All_users = new List<string>();
			string prikaz = "Select * from uzivatele;";
			SqlCommand command2 = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					All_users.Add(reader["username"].ToString());
				}
			}
			cnn.Close();
			return All_users;

		}

		/// <summary>
		/// Method for getting names of all groups from table Skupiny
		/// </summary>
		/// <returns>List of strings of group names</returns>
		public static List<string> Get_all_groups()
		{
			SqlConnection cnn = ConnectDB();
			List<string> All_groups = new List<string>();
			string prikaz = "Select * from skupiny;";
			SqlCommand command2 = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					All_groups.Add(reader["nazev"].ToString());
				}
			}
			cnn.Close();
			return All_groups;
		}
	}
}
