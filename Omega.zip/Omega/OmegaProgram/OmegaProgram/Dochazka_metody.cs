﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using static OmegaProgram.Zaci_metody;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Treninky_metody;

namespace OmegaProgram
{
	class Dochazka_metody
	{
		/// <summary>
		/// Method for inserting new log to table dochazka
		/// </summary>
		/// <param name="skupina"></param>
		/// <param name="jmeno_prijmeni"></param>
		/// <param name="datum_cas"></param>
		/// <param name="prezence"></param>
		public static void Insert_to_dochazka(string jmeno_prijmeni, string datum_cas, string prezence)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "insert into dochazka(id_zak, id_trenink, prezence) values("+Get_id_of_athelet_thru_name(jmeno_prijmeni)+", "+ Get_id_of_trenink(datum_cas)+", '"+prezence+"'); ";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();
		}
		/// <summary>
		/// Method for getting information about presence of concrete student
		/// </summary>
		/// <param name="jmeno"></param>
		/// <param name="datum_cas"></param>
		/// <returns>string: Přítomen or Nepřítomen or Omluven</returns>
		public static string Select_dochazka(string jmeno, string datum_cas)
		{
			SqlConnection cnn = ConnectDB();
			string prezence = null;
			string prikaz = "select prezence from dochazka d inner join Zaci z on d.id_zak = z.id_zak where z.id_zak ="+Get_id_of_athelet_thru_name(jmeno)+" and d.id_trenink ="+Get_id_of_trenink(datum_cas)+";";
			SqlCommand command = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					prezence = reader["prezence"].ToString();
				}
			}
			cnn.Close();
			return prezence;
		}
		/// <summary>
		/// Method for editing presence of concrete student
		/// </summary>
		/// <param name="jmeno_prijmeni"></param>
		/// <param name="datum_cas"></param>
		/// <param name="prezence"></param>
		public static void Update_dochazka(string jmeno_prijmeni, string datum_cas, string prezence)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "Update dochazka set prezence = '"+ prezence +"' where id_zak = "+Get_id_of_athelet_thru_name(jmeno_prijmeni)+" and id_trenink = " + Get_id_of_trenink(datum_cas)+"; ";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();
		}

	}
}
