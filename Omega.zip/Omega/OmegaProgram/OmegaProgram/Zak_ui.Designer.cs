﻿namespace OmegaProgram
{
	partial class Zak_ui
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zak_ui));
			this.uzivatel_lbl = new System.Windows.Forms.Label();
			this.jmeno_lbl = new System.Windows.Forms.Label();
			this.prijmeni_lbl = new System.Windows.Forms.Label();
			this.dochazka_button = new System.Windows.Forms.Button();
			this.inf_button = new System.Windows.Forms.Button();
			this.zpet_button = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// uzivatel_lbl
			// 
			this.uzivatel_lbl.AutoSize = true;
			this.uzivatel_lbl.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.uzivatel_lbl.Location = new System.Drawing.Point(372, 23);
			this.uzivatel_lbl.Name = "uzivatel_lbl";
			this.uzivatel_lbl.Size = new System.Drawing.Size(206, 35);
			this.uzivatel_lbl.TabIndex = 0;
			this.uzivatel_lbl.Text = "Vítejte uživateli:";
			// 
			// jmeno_lbl
			// 
			this.jmeno_lbl.AutoSize = true;
			this.jmeno_lbl.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.jmeno_lbl.Location = new System.Drawing.Point(372, 75);
			this.jmeno_lbl.Name = "jmeno_lbl";
			this.jmeno_lbl.Size = new System.Drawing.Size(91, 35);
			this.jmeno_lbl.TabIndex = 2;
			this.jmeno_lbl.Text = "Jméno";
			// 
			// prijmeni_lbl
			// 
			this.prijmeni_lbl.AutoSize = true;
			this.prijmeni_lbl.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.prijmeni_lbl.Location = new System.Drawing.Point(484, 75);
			this.prijmeni_lbl.Name = "prijmeni_lbl";
			this.prijmeni_lbl.Size = new System.Drawing.Size(113, 35);
			this.prijmeni_lbl.TabIndex = 3;
			this.prijmeni_lbl.Text = "Přijmení";
			// 
			// dochazka_button
			// 
			this.dochazka_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.dochazka_button.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.dochazka_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.dochazka_button.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.dochazka_button.Location = new System.Drawing.Point(102, 23);
			this.dochazka_button.Name = "dochazka_button";
			this.dochazka_button.Size = new System.Drawing.Size(173, 50);
			this.dochazka_button.TabIndex = 4;
			this.dochazka_button.Text = "Tréninky";
			this.dochazka_button.UseVisualStyleBackColor = false;
			this.dochazka_button.Click += new System.EventHandler(this.dochazka_button_Click);
			// 
			// inf_button
			// 
			this.inf_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.inf_button.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.inf_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.inf_button.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.inf_button.Location = new System.Drawing.Point(102, 93);
			this.inf_button.Name = "inf_button";
			this.inf_button.Size = new System.Drawing.Size(177, 50);
			this.inf_button.TabIndex = 5;
			this.inf_button.Text = "Informace";
			this.inf_button.UseVisualStyleBackColor = false;
			this.inf_button.Click += new System.EventHandler(this.inf_button_Click);
			// 
			// zpet_button
			// 
			this.zpet_button.ForeColor = System.Drawing.Color.Black;
			this.zpet_button.Location = new System.Drawing.Point(12, 405);
			this.zpet_button.Name = "zpet_button";
			this.zpet_button.Size = new System.Drawing.Size(84, 27);
			this.zpet_button.TabIndex = 6;
			this.zpet_button.Text = "Zpět";
			this.zpet_button.UseVisualStyleBackColor = true;
			this.zpet_button.Click += new System.EventHandler(this.zpet_button_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(31, 23);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(65, 64);
			this.pictureBox1.TabIndex = 7;
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(31, 93);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(65, 65);
			this.pictureBox2.TabIndex = 8;
			this.pictureBox2.TabStop = false;
			// 
			// Zak_ui
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.ClientSize = new System.Drawing.Size(678, 444);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.zpet_button);
			this.Controls.Add(this.inf_button);
			this.Controls.Add(this.dochazka_button);
			this.Controls.Add(this.prijmeni_lbl);
			this.Controls.Add(this.jmeno_lbl);
			this.Controls.Add(this.uzivatel_lbl);
			this.ForeColor = System.Drawing.Color.White;
			this.Name = "Zak_ui";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Žák";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label uzivatel_lbl;
		private System.Windows.Forms.Label jmeno_lbl;
		private System.Windows.Forms.Label prijmeni_lbl;
		private System.Windows.Forms.Button dochazka_button;
		private System.Windows.Forms.Button inf_button;
		private System.Windows.Forms.Button zpet_button;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
	}
}