﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Uzivatele_metody;

namespace OmegaProgram
{
	public partial class Prihlaseni_ui : Form
	{
		public Prihlaseni_ui()
		{
			InitializeComponent();
			this.Location = new Point(0, 0);
			//posouvání se pomocí tabulátoru
			login_box.TabIndex = 1;
			login_box.TabStop = true;
			heslo_box.TabIndex = 2;
			heslo_box.TabStop = true;
			prihlasit_button.TabIndex = 3;
			prihlasit_button.TabStop = true;
		}
		private void button1_Click(object sender, EventArgs e)
		{
			string login = login_box.Text;
			string helso = heslo_box.Text;
			ConnectDB();

			if(Sing_on(login, helso))
			{
				if (Get_type_of_user().Equals("trener")) {
					this.Hide();
					Trener_ui a1 = new Trener_ui();
					a1.ShowDialog();
				}
				else if(Get_type_of_user().Equals("zak"))
				{
					this.Hide();
					Zak_ui a1 = new Zak_ui();
					a1.ShowDialog();
				}
				else if (Get_type_of_user().Equals("admin"))
				{
					this.Hide();
					Admin_ui a1 = new Admin_ui();
					a1.ShowDialog();
				}
			}
			
		}

		private void registrace_Click(object sender, EventArgs e)
		{
			this.Hide();
			Registrace a1 = new Registrace();
			a1.ShowDialog();
		}

		private void Prihlaseni_ui_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}
	}
}
