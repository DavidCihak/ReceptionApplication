1) Informace o tom jak vytvořit uživatele, databázi, tabulky které následně naplníme daty naleznete ve složce: Dokumentace
V souboru: Pred_spustenim

2) Konfigurační soubor naleznete zde: 
Omega -> OmegaProgram - > OmegaProgram -> bin -> Debug -> Data (Omega\OmegaProgram\OmegaProgram\bin\Debug\Data)
- ve složce Data v textovém souboru: DB_Udaje.txt

V konfiguračním souboru:
Přímo za = píšeme ihned naše údaje!
Pokud jste pracovali podle souboru Pred_spustenim, změníte pouze to co je v 1. řádku za hlavičkou: Server=

Příklad:
Server=DESKTOP-V9M6O1K <- tento řádek se změní konkrétně místo: DESKTOP-V9M6O1k bude název vašeho severu. Ve škole např.: PC-25
Database=Omega
Username=david
Password=david

3) Stručný popis jak se dostat ke spustitelnému souboru (celý popis naleznete v Pred_spustenim):  
Omega\OmegaProgram\OmegaProgram\bin\Debug spustit soubor OmegaProgram.exe


4) Testovací data pro přihlášní jsou:

A)Pro uživatele Trenér:
Uživatelské jméno: david
Heslo: david

B)Pro uživatele Žák:
Uživatelské jméno: honza
Heslo: honza

C)Pro uživatele Admin:
Uživatelské jméno: admin
Heslo: admin

Pokud se po kliknutí na "Přihlásit se" aplikace vypne, tak databáze, ke které se program pokusil připojit je vypnutá nebo obsazená.








Konec
David Čihák