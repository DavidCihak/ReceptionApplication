﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Treneri_metody;
using static OmegaProgram.Zaci_metody;

namespace OmegaProgram
{
	class Skupiny_metody
	{

		/// <summary>
		/// Method for getting id of skuping through name of the skupina
		/// </summary>
		/// <param name="nazev"></param>
		/// <returns>string id nubmer of the concrete group</returns>
		public static string Get_id_skup(string nazev)
		{
			SqlConnection cnn = ConnectDB();
			string id_skup = null;
			string prikaz_udaje = "Select id_skup from skupiny where nazev = '" + nazev + "';";
			SqlCommand command2 = new SqlCommand(prikaz_udaje, ConnectDB());

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_skup = reader["id_skup"].ToString();
				}
			}
			cnn.Close();
			return id_skup;
		}
		/// <summary>
		/// Method for getting all groups which trener train/coach
		/// </summary>
		/// <returns>list of string names of groups</returns>
		public static List<string> Get_skupiny_of_trener()
		{
			SqlConnection cnn = ConnectDB();
			List<string> Skupiny = new List<string>();
			string prikaz_skup = "Select nazev from skupiny where id_trener = " + Get_id_of_trener() + ";";
			SqlCommand command3 = new SqlCommand(prikaz_skup, cnn);

			using (SqlDataReader reader = command3.ExecuteReader())
			{
				while (reader.Read())
				{
					Skupiny.Add(reader["nazev"].ToString());
				}
			}
			cnn.Close();
			return Skupiny;
		}

		/// <summary>
		/// Method for getting all groups where is our athlet
		/// </summary>
		/// <returns>list of string names of groups</returns>
		public static List<string> Get_skupiny_of_zak()
		{
			SqlConnection cnn = ConnectDB();
			List<string> Skupiny = new List<string>();
			//inner join
			string prikaz_skup = "select s.nazev from skupiny s inner join zaci z on s.id_skup = z.id_skup where id_zak =" + Get_id_of_athelte() + ";";
			SqlCommand command3 = new SqlCommand(prikaz_skup, cnn);

			using (SqlDataReader reader = command3.ExecuteReader())
			{
				while (reader.Read())
				{
					Skupiny.Add(reader["nazev"].ToString());
				}
			}
			cnn.Close();
			return Skupiny;
		}
	}
}
