﻿//using System;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Uzivatele_metody;


namespace OmegaProgram
{
	class Zaci_metody
	{
		/// <summary>
		/// Method for getting id of athlete through id of uzivatele
		/// </summary>
		/// <param name="id_user"></param>
		/// <returns>string id of athlete</returns>
		public static string Get_id_of_athlete_thru_user_id(string id_user)
		{
			SqlConnection cnn = ConnectDB();
			string id_zak = null;
			string prikaz_id_tren = "Select id_zak from zaci where id_uziv = " + id_user + ";";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_zak = reader["id_zak"].ToString();
				}
			}
			return id_zak;
		}
		
		/// <summary>
		/// Method for getting any of atributes from table zaci
		/// </summary>
		/// <param name="atribut"></param>
		/// <returns>string of concrete atribut</returns>
		public static string Get_something_from_zaci(string atribut)
		{

			SqlConnection cnn = ConnectDB();
			string neco = null;
			string prikaz = "Select " + atribut + " from zaci where id_uziv = " + Get_id_of_user() + ";";
			SqlCommand command2 = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					neco = reader[atribut].ToString();
				}
			}
			cnn.Close();
			return neco;
		}

		/// <summary>
		/// Method for getting bazal calories thru atribut of weight from table zaci
		/// </summary>
		/// <returns>string of new number of count calories</returns>
		public static double Get_bazal_of_zak()
		{
			string hmotnost = Get_something_from_zaci("hmotnost_kg");
			double bazal = double.Parse(hmotnost);
			bazal = bazal * 1.3 * 24;
			return bazal;
		}
		/// <summary>
		/// Method to get split winForm formate of date to list of chars
		/// </summary>
		/// <param name="text"></param>
		/// <returns>list of chars </returns>
		public static string[] Split_date_others(string text)
		{
			char[] znaky = new char[] { '.', '=',' ', '\t', ','};
			string[] rozdeleno = text.Split(znaky);
			return rozdeleno;
		}
		/// <summary>
		/// Method for gettig name and surname of concrete athlete thru id of user
		/// </summary>
		/// <returns>list of stings name and surname</returns>
		public static List<string> Get_name_surname_of_zak()
		{
			SqlConnection cnn = ConnectDB();
			List<string> udaje = new List<string>();
			string prikaz_udaje = "Select jmeno, prijmeni from zaci where id_uziv = " + Get_id_of_user() + ";";
			SqlCommand command2 = new SqlCommand(prikaz_udaje, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					udaje.Add(reader["jmeno"].ToString());
					udaje.Add(reader["prijmeni"].ToString());
				}
			}
			cnn.Close();
			return udaje;

		}
		/// <summary>
		/// Method for gettig id concrete athelte thru his name and surname
		/// </summary>
		/// <param name="jmeno_prijmeni"></param>
		/// <returns>string of id of concrete athelete</returns>
		public static string Get_id_of_athelet_thru_name(string jmeno_prijmeni)
		{
			SqlConnection cnn = ConnectDB();
			string id_zak = null;
			string[] rozdeleno = Split_date_others(jmeno_prijmeni);
			string prikaz_udaje = "Select id_zak from zaci where jmeno = '" + rozdeleno[0] + "' and prijmeni = '" + rozdeleno[1] + "';";
			SqlCommand command2 = new SqlCommand(prikaz_udaje, ConnectDB());

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_zak = reader["id_zak"].ToString();
				}
			}
			cnn.Close();
			return id_zak;
		}
		/// <summary>
		/// Method for getting id of concrete athlete thru id of user
		/// </summary>
		/// <returns>string of id of concrete athelete</returns>
		public static string Get_id_of_athelte()
		{
			SqlConnection cnn = ConnectDB();
			string id_tren = null;
			string prikaz_id_tren = "Select id_zak from zaci where id_uziv = " + Get_id_of_user() + ";";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					id_tren = reader["id_zak"].ToString();

				}
				return id_tren;

			}
		}
		/// <summary>
		/// Method for getting all atributes from table zaci about concrete athlete
		/// </summary>
		/// <param name="jmeno_prijmeni"></param>
		/// <returns>List of strings of informations bout athlete</returns>
		public static List<string> Select_all_from_zaci(string jmeno_prijmeni)
		{
			SqlConnection cnn = ConnectDB();
			string[] rozdeleno = Split_date_others(jmeno_prijmeni);
			List<string> seznam_infor_lbl = new List<string>();
			string prikaz = "select * from zaci where jmeno='" + rozdeleno[0] + "' and prijmeni='" + rozdeleno[1] + "'";
			SqlCommand command = new SqlCommand(prikaz, cnn);

			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					seznam_infor_lbl.Clear();
					seznam_infor_lbl.Add(reader["jmeno"].ToString());
					seznam_infor_lbl.Add(reader["prijmeni"].ToString());
					seznam_infor_lbl.Add(reader["dat_naroz"].ToString());
					seznam_infor_lbl.Add(reader["vyska_cm"].ToString());
					seznam_infor_lbl.Add(reader["hmotnost_kg"].ToString());
					seznam_infor_lbl.Add(reader["bmi"].ToString());
					seznam_infor_lbl.Add(reader["poznamka_zraneni_strava"].ToString());

				}
			}
			
			cnn.Close();
			return seznam_infor_lbl;
		}

		/// <summary>
		/// Method for getting all athletes which are in concrete group thru id_skup
		/// </summary>
		/// <param name="nazev_skup"></param>
		/// <returns>List of string of names and surnames of all athletes in group</returns>
		public static List<string> Get_athletes_thru_skupina(string nazev_skup)
		{
			SqlConnection cnn = ConnectDB();
			List<string> Zaci = new List<string>();
			string prikaz = "select jmeno, prijmeni from skupiny s inner join zaci z on s.id_skup = z.id_skup where s.nazev='" + nazev_skup + "';";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					string jmeno_zak = reader["jmeno"].ToString();
					string prijmeni_zak = reader["prijmeni"].ToString();
					Zaci.Add(jmeno_zak + " " + prijmeni_zak);
				}
			}
			cnn.Close();
			return Zaci;
		}
		/// <summary>
		/// Method for updatig all atributes of concrete athlete+automatic counting bmi
		/// </summary>
		/// <param name="vse"></param>
		/// <param name="id_zak"></param>
		public static void Update_athlete_all(List<string> vse, string id_zak)
		{
			List<string> atributy = new List<string>();
			atributy.Add("jmeno");
			atributy.Add("prijmeni");
			atributy.Add("dat_naroz");
			atributy.Add("vyska_cm");
			atributy.Add("hmotnost_kg");
			atributy.Add("bmi");
			atributy.Add("poznamka_zraneni_strava");
			SqlConnection cnn = ConnectDB();


			for (int i = 0; i < 3; i++)
			{	
				if (i == 3)
				{
					string[] text = Split_date_others(vse[i]);
					string upraveno = text[2] + "-" + text[1] + "-" + text[0] + " " + text[3];
					string prikaz = "update zaci set " + atributy[i] + " = @upraveno where id_zak = " + id_zak + ";";
					SqlCommand command = new SqlCommand(prikaz, cnn);
					command.Parameters.Add("@upraveno", SqlDbType.Date);
					command.Parameters["@upraveno"].Value = upraveno;
					command.ExecuteNonQuery();
				}
				else
				{				
					string prikaz = "update zaci set " + atributy[i] + " = @vse where id_zak = " + id_zak + ";";
					SqlCommand command = new SqlCommand(prikaz, cnn);
					command.Parameters.Add("@vse", SqlDbType.NVarChar);
					command.Parameters["@vse"].Value = vse[i];
					command.ExecuteNonQuery();
				}	
				
			}
			for (int i = 3; i < 6; i++)
			{
				string[] text = Split_date_others(vse[i]);
				string upraveno;
				if (text.Length > 1)
				{
					upraveno = text[0] + "." + text[1];
				}
				else
				{
					upraveno = text[0];
				}
				if (atributy[i] == "bmi")
				{
					//vypocet bmi
					double hmotnost = double.Parse(vse[4]);
					double vyska = double.Parse(vse[3]) / 100;
					double bmi = hmotnost / (vyska * vyska);
					double fc = (double)Math.Round(bmi * 100) / 100;

					string prikaz = "update zaci set " + atributy[i] + " = @upraveno where id_zak = " + id_zak + ";";
					SqlCommand command = new SqlCommand(prikaz, cnn);
					command.Parameters.Add("@upraveno", SqlDbType.Float);
					command.Parameters["@upraveno"].Value = fc;
					command.ExecuteNonQuery();
				}
				else
				{
					string prikaz = "update zaci set " + atributy[i] + " = @upraveno where id_zak = " + id_zak + ";";
					SqlCommand command = new SqlCommand(prikaz, cnn);
					command.Parameters.Add("@upraveno", SqlDbType.Float);
					command.Parameters["@upraveno"].Value = upraveno;
					command.ExecuteNonQuery();
				}
				
			}
			string prikazz = "update zaci set " + atributy[6] + " = @info where id_zak = " + id_zak + ";";
			SqlCommand commandd = new SqlCommand(prikazz, cnn);
			commandd.Parameters.Add("@info", SqlDbType.NVarChar);
			commandd.Parameters["@info"].Value = vse[6];
			commandd.ExecuteNonQuery();
			cnn.Close();
		}

	}
}
