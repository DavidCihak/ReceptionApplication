﻿using System.Data;
using System.Data.SqlClient;
using static OmegaProgram.Pripojeni_db;

namespace OmegaProgram
{
	class Uzivatele_metody
	{
		/// <summary>
		/// Method for getting typ of user through id of uzivatele
		/// </summary>
		/// <param name="id_user"></param>
		/// <returns>string type user</returns>
		public static string Get_type_of_user_thru_user_id(string id_user)
		{
			SqlConnection cnn = ConnectDB();
			string typ = null;
			string prikaz_id_tren = "Select typ_uziv from uzivatele where id_uziv = " + id_user + ";";
			SqlCommand command2 = new SqlCommand(prikaz_id_tren, cnn);

			using (SqlDataReader reader = command2.ExecuteReader())
			{
				while (reader.Read())
				{
					typ = reader["typ_uziv"].ToString();
				}
			}
			return typ;
		}
		
		
		/// <summary>
		/// Method for getting id of uzivatel thru accepted login and password
		/// </summary>
		/// <returns>string id of concrete uzivatel</returns>
		public static string Get_id_of_user()
		{
			SqlConnection cnn = ConnectDB();
			string id_uziv = null;
			string id_uziv_comm = "select id_uziv from uzivatele where username = '" + get_login() + "' and heslo = '" + get_heslo() + "';";
			SqlCommand command1 = new SqlCommand(id_uziv_comm, cnn);
			using (SqlDataReader reader = command1.ExecuteReader())
			{
				while (reader.Read())
				{
					id_uziv = reader["id_uziv"].ToString();
				}
			}
			return id_uziv;
		}
		public static string Get_id_of_user_nick(string nick)
		{
			SqlConnection cnn = ConnectDB();
			string id_uziv = null;
			string id_uziv_comm = "select id_uziv from uzivatele where username = '" + nick + "';";
			SqlCommand command1 = new SqlCommand(id_uziv_comm, cnn);
			using (SqlDataReader reader = command1.ExecuteReader())
			{
				while (reader.Read())
				{
					id_uziv = reader["id_uziv"].ToString();
				}
			}
			return id_uziv;
		}
		/// <summary>
		/// Method for gettig what role user have
		/// </summary>
		/// <returns>string zak or trener</returns>
		public static string Get_type_of_user()
		{
			SqlConnection cnn = ConnectDB();
			string typ_uziv = null;
			string prikaz_uziv = "select typ_uziv from uzivatele where username = '" + get_login() + "' and heslo = '" + get_heslo() + "';";
			SqlCommand uziv_command = new SqlCommand(prikaz_uziv, cnn);
			using (SqlDataReader reader = uziv_command.ExecuteReader())
			{
				while (reader.Read())
				{

					typ_uziv = reader["typ_uziv"].ToString();
				}
				cnn.Close();
				return typ_uziv;
			}
		}
	}
}
