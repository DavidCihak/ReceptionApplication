﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using static OmegaProgram.Pripojeni_db;
using static OmegaProgram.Skupiny_metody;
using static OmegaProgram.Zaci_metody;
using System.Data;

namespace OmegaProgram
{
	class Treninky_metody
	{
		/// <summary>
		/// Method for getting id of trenink through concrete date and time in one string
		/// </summary>
		/// <param name="datum_cas"></param>
		/// <returns>string id of concrete train</returns>
		public static string Get_id_of_trenink(string datum_cas)
		{
			string[] text = Split_date_others(datum_cas);
			Console.WriteLine(text);
			SqlConnection cnn = ConnectDB();
			string datum = text[2] + "-" + text[1] + "-" + text[0] + " " + text[3];
			string prikaz = "SELECT id_trenink from treninky where datum_cas ='" + datum + "'; ";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			string id_treninku = null;
			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					id_treninku = reader["id_trenink"].ToString();
				}

			}
			cnn.Close();
			return id_treninku;
		}
		/// <summary>
		/// Method to get all trainings of concrete group thru her name
		/// </summary>
		/// <param name="skupina"></param>
		/// <returns>List of strings of dates concrete train</returns>
		public static List<string> Get_treninky_futurePast_week(string skupina)
		{
			List<string> data = new List<string>();
			SqlConnection cnn = ConnectDB();
			string prikaz = "SELECT * from treninky where(datum_cas BETWEEN GETDATE()-7 AND GETDATE() + 7) and id_skup = " + Get_id_skup(skupina) + ";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					string datum = reader["datum_cas"].ToString();
					data.Add(datum);
				}

			}
			cnn.Close();
			return data;
		}
		/// <summary>
		/// Method for getting all treainings what exists and are for concrete athlete
		/// </summary>
		/// <param name="nazev"></param>
		/// <returns>List of strings of informations about trainings</returns>
		public static List<string> Get_trainings_of_athlete(string nazev)
		{
			List<string> treninky = new List<string>();
			SqlConnection cnn = ConnectDB();
			string prikaz = "SELECT * from treninky where id_skup = " + Get_id_skup(nazev) +";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					string trenink = "Název:  " + reader["nazev"].ToString() + "\nDatum a čas: " + reader["datum_cas"].ToString() + "\nPopis: " + reader["popis"].ToString() + "\nDélka: " + reader["delka_min"].ToString() + " min";
					treninky.Add(trenink);
				}

			}
			cnn.Close();
			return treninky;
		}
		/// <summary>
		/// Method to insert new log to table treninky
		/// </summary>
		/// <param name="id_skup"></param>
		/// <param name="nazev_tren"></param>
		/// <param name="popis"></param>
		/// <param name="datum"></param>
		/// <param name="delka"></param>
		public static void Insert_trenink(string id_skup, string nazev_tren, string popis,	string datum, string delka)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "insert into treninky(id_skup, nazev, popis, datum_cas,delka_min) values ("+id_skup+",'"+nazev_tren+ "','" + popis + "','" + datum + "'," + delka + ");";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();
		}
		/// <summary>
		/// Method for deleting concrete log in table treninky
		/// </summary>
		/// <param name="id_skup"></param>
		/// <param name="id_tren"></param>
		public static void Delete_trenink(string id_skup, string id_tren)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "DELETE FROM treninky WHERE id_skup="+id_skup+"and id_trenink="+id_tren+";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.ExecuteNonQuery();
			cnn.Close();
		}
		/// <summary>
		/// Method to get all 
		/// </summary>
		/// <param name="id_skup"></param>
		/// <param name="id_tren"></param>
		/// <returns></returns>
		public static List<string> Select_treninky_thru_idSku_idTrenink(string id_skup, string id_tren)
		{
			SqlConnection cnn = ConnectDB();
			List<string> treninky = new List<string>();
			string prikaz = "select * from treninky where id_skup=" + id_skup + " and id_trenink =" + id_tren + ";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			using (SqlDataReader reader = command.ExecuteReader())
			{
				while (reader.Read())
				{
					string trenink = "Název:  " + reader["nazev"].ToString() + "\nDatum a čas: " + reader["datum_cas"].ToString() + "\nPopis: " + reader["popis"].ToString() + "\nDélka: " + reader["delka_min"].ToString() + " min";
					treninky.Add(trenink);
				}

			}
			cnn.Close();
			return treninky;

		}
		/// <summary>
		/// Method for choose if user want to edit nvarchar or int in DB
		/// </summary>
		/// <param name="skupina"></param>
		/// <param name="id_tren"></param>
		/// <param name="atribut"></param>
		/// <param name="new_parametr"></param>
		public static void Update_trenink_choose(string skupina,string id_tren, string atribut, string new_parametr)
		{
			if (atribut == "delka_min")
			{
				Update_trenink_float(skupina, id_tren, atribut, new_parametr);
			}
			else if(atribut == "datum_cas")
			{
				SqlConnection cnn = ConnectDB();
				string[] text = Split_date_others(new_parametr);
				string datum = text[2] + "-" + text[1] + "-" + text[0];
				string prikaz = "update treninky set " + atribut + " = @new_parametr where id_skup=" + skupina + " and id_trenink = " + id_tren + ";";
				SqlCommand command = new SqlCommand(prikaz, cnn);
				command.Parameters.Add("@new_parametr", SqlDbType.Date);
				command.Parameters["@new_parametr"].Value = datum;
				command.ExecuteNonQuery();
				cnn.Close();
			}
			else
			{
				Update_trenink_string(skupina, id_tren, atribut, new_parametr);
			}
		}
		/// <summary>
		/// Method to update atribute of datatype what need to be written in apostrofes
		/// </summary>
		/// <param name="skupina"></param>
		/// <param name="id_trenink"></param>
		/// <param name="atribut"></param>
		/// <param name="new_parametr"></param>
		public static void Update_trenink_string(string skupina, string id_trenink, string atribut, string new_parametr)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "update treninky set " + atribut + " = @new_parametr where id_skup=" + skupina+" and id_trenink = "+ id_trenink+";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@new_parametr", SqlDbType.NVarChar);
			command.Parameters["@new_parametr"].Value = new_parametr;
			command.ExecuteNonQuery();
			cnn.Close();
		}
		/// <summary>
		/// Method to update atribute of datatype what dont need to be written in apostrofes
		/// </summary>
		/// <param name="skupina"></param>
		/// <param name="id_trenink"></param>
		/// <param name="atribut"></param>
		/// <param name="new_parametr"></param>
		public static void Update_trenink_float(string skupina, string id_trenink, string atribut, string new_parametr)
		{
			SqlConnection cnn = ConnectDB();
			string prikaz = "update treninky set " + atribut + " = @new_parametr where id_skup=" + skupina + " and id_trenink = " + id_trenink + ";";
			SqlCommand command = new SqlCommand(prikaz, cnn);
			command.Parameters.Add("@new_parametr", SqlDbType.Float);
			command.Parameters["@new_parametr"].Value = new_parametr;
			command.ExecuteNonQuery();
			cnn.Close();
		}
	}
}
